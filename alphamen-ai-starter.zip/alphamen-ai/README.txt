ALPHAMEN AI — ANDROID STARTER
=============================

WHAT THIS VERSION DOES
- Mobile-friendly cinematic studio interface
- Text prompt presets
- Image reference preview (up to 5 MB)
- YouTube / Reels / square format settings
- Telugu / English / Hindi voice-over setting in the brief
- Saves recent prompt briefs in browser local storage
- Copies or downloads a .txt generation brief
- PWA manifest and service worker for install/offline shell

IMPORTANT LIMITATION
This starter does NOT render AI videos yet. A real text-to-video/image-to-video
engine needs a hosted GPU model or a third-party API and a secure backend.
Do not put private API keys in app.js or any public frontend file.
The 4K option is an export/upscaling target, not native 4K AI rendering.

RUN ON ANDROID WITH CHROME
1. Download and extract alphamen-ai-starter.zip.
2. To test locally, open index.html in Chrome. Some PWA features require HTTPS.
3. For an installable web app, publish the folder to GitHub Pages:
   a. Sign in at https://github.com
   b. Create a public repository named alphamen-ai
   c. Upload all files from this folder (not the ZIP itself).
   d. Open repository Settings > Pages.
   e. Under Build and deployment, choose Deploy from a branch.
   f. Choose main and /(root), then Save.
   g. Wait for the Pages URL to appear.
4. Open the Pages URL in Chrome on Android.
5. Chrome menu (three dots) > Add to Home screen / Install app.

NEXT DEVELOPMENT STEP
Connect a hosted video-generation model. This requires choosing a provider,
checking its current free quota, and implementing a server-side endpoint.
A phone browser alone cannot run large cinematic video models locally.
